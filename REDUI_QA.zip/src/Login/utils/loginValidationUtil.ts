export function validateCredentials() {
    return true;
}