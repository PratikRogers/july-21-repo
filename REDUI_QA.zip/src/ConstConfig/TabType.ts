export enum TabType {
    MBOILE="mobile",
    TABLET="tablet",
    DESKTOP="desktop"
}

export default TabType;