export enum KeysConstants {
    Login="Login",
    UserLogin="USER_LOGIN",
    ChangeConfig= "CHANGE_CONFIG",

}

export default KeysConstants;