/* eslint-disable */
export enum KeyCode {
    ENTER = 13,
    TAB = 9,
    ESCAPE = 27
}

export default KeyCode;