export enum UIConstants {
   Spaces = 4

}

export default UIConstants;

