/* eslint-disable */
export enum ErrorConstants {
    ERROR_401="error_401",
}

export default ErrorConstants;