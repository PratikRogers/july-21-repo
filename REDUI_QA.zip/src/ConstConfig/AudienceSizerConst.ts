export enum AudienceSizerConst {
     LINKNONE=0,
     LINKUP=1,
     LINKBOTH=2,
     LINKDOWN=3,
    
}

export default AudienceSizerConst;