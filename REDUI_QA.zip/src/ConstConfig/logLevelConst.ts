/* eslint-disable */
export enum LOGLEVEL{
    INFO=1,
    WARN=2,
    DEBUG=3,
    ERROR=4
}

export default LOGLEVEL;