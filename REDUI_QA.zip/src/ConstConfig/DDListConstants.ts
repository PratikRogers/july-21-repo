export enum DDListConstants {
    LIST1 = 1,
    LIST2 = 2,
}

export default DDListConstants;
