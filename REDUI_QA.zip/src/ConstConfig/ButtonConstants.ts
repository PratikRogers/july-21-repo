export enum ButtonConstants {
    OK="OK",
    CANCEL="CANCEL",
    CONTINUE= "CONTINUE"
}

export default ButtonConstants;