export enum CarousalTabItemsModel {
    PLANNING = 0,
    DEMOGRAPHICS = 1,
    INTRESTS = 2,
    BEHAVIOR = 3,
}

export default CarousalTabItemsModel;