export declare const BaseFeatures: {
    actionsToComputedPropertyName: <T>(actions: T) => { [key in keyof T]: string; };
}